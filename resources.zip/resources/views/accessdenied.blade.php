<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Oops !</title>
</head>
<body>
	<h3><u>Warning !</u></h3>

	<p style="color: red">You tried to change the domain which is invalid ! Please contact <a href="https://codecanyon.net/item/eclass-learning-management-system/25613271/support">Support</a> for update in domain.</p>

	<h4 style="color:green">You can use this project only in single domain for multiple domain please check License standard <a href="https://codecanyon.net/licenses/standard">here</a>.</h4>
</body>
</html>